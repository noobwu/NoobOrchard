 public string GetMapProperty(EntityMember em,bool isReplaceId=false)
{
	string strProperty=null;
	string propertyName=GetPropertyName(em,isReplaceId);
	if(propertyName!=em.ColumnName)
	{
		strProperty=string.Format("Map(t => t.{0}).Column(\"{1}\")",propertyName,em.ColumnName)+";";
	}
    return strProperty;
}
public string GetCompositeKey(EntityManager entityManager,bool isReplaceId=false)
{
	 if(entityManager.PrimaryKey==null||!entityManager.PrimaryKey.IsCompositeKey)
    {
        return "";
    }
	string fieldNames="";
	foreach(EntityMember em in entityManager.PrimaryKey.KeyColumns)
	{
		fieldNames+="t."+GetPropertyName(em,isReplaceId)+",";
	}
	//return "HasKey(t =>new {"+fieldNames.Trim(',')+"});";
	return "";
}
public string GetMapColumnName(string propertyName,EntityMember em)
{
	if(propertyName!=em.ColumnName)
	{
		return ".Column(\""+em.ColumnName+"\")";
	}
	return string.Empty;
}	

 /// <summary>
/// 
/// </summary>
/// <param name="em"></param>
/// <param name="isReplaceId"></param>
/// <param name="primaryKeyType">0:主键,1:自动增长Id,2:复合主键</param>
 public string GetPrimaryKeyMapProperty(EntityMember em,bool isReplaceId=false,int primaryKeyType=0)
{
	string propertyName=GetPropertyName(em,isReplaceId);
    string strProperty=string.Format("Map(t => t.{0})",propertyName);
	if(propertyName!=em.ColumnName)
	{
		strProperty+=string.Format(".Column(\"{0}\")",em.ColumnName);
	}
	switch(primaryKeyType)
	{
	   case 0: 
             strProperty+=".Key(KeyType.Assigned)";	   
		break;
	   case 1: 
             strProperty+=".Key(KeyType.Identity)";	   
		break;
	   default:
	     strProperty+=".Key(KeyType.NotAKey)";	   
	   break;
	}
    return strProperty+";";
}