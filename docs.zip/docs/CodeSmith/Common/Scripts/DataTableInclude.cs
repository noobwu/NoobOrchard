public string GetPrimaryProperty(EntityMember em,bool isReplaceId=false)
{
    if(em.ColumnName.ToLower()=="id")
    {
       return "public override "+GetSystemTypeName(em.Column)+" Id {  get;set; }";
    }
    else
    {
       //return "public virtual "+GetSystemTypeName(em.Column)+" "+em.PropertyName+ " { get { return Id; } set { } }";  
        return "public virtual "+GetSystemTypeName(em.Column)+" "+GetPropertyName(em,isReplaceId)+ " {  get;set; }";  
    }
      
}
public string GetPropertyName(EntityMember em,bool isReplaceId=false)
{
	string propertyName=em.PropertyName;
	if(isReplaceId)
	{
		propertyName= propertyName.Replace("ID","Id");
	}
	return propertyName;
}

public string GetEAPropertyName(EntityAssociation ea,bool isReplaceId=false)
{
	string propertyName=StringUtil.ToPascalCase(ea.ColumnName);
    if(isReplaceId)
	{
		propertyName= propertyName.Replace("ID","Id");
	}
	return propertyName;
}
public string GetSoftDeleteInterface(EntityManager entityManager)
{
      if(entityManager.AllMembers.Exists(a=>a.ColumnName=="DeleteFlag"))
      {
          return ",ISoftDelete";
      }
      else{
          return null;
      }
}
public string GetPrimaryKeySystemType(TableSchema sourceTable,EntityManager entityManager)
{
    if(!sourceTable.HasPrimaryKey||entityManager.PrimaryKey.KeyColumns==null||entityManager.PrimaryKey.KeyColumns.Count==0)
    {
        return "int";
    }
	if(entityManager.PrimaryKey.KeyColumns.Count==1)
	{
	  return GetSystemTypeName(entityManager.PrimaryKey.KeyColumns[0].Column);
	}
    else{
		return "string";
	}
}
public string GetPrimaryKeyPropertyName(TableSchema sourceTable,EntityManager entityManager,bool isReplaceId=false)
{
	 if(!sourceTable.HasPrimaryKey||entityManager.PrimaryKey.KeyColumns==null||entityManager.PrimaryKey.KeyColumns.Count==0)
    {
        return "";
    }
	if(entityManager.PrimaryKey.KeyColumns.Count==1)
	{
	  return GetPropertyName(entityManager.PrimaryKey.KeyColumns[0],isReplaceId);
	}
    else{
		string propertyName="";
	    foreach(EntityMember em in entityManager.PrimaryKey.KeyColumns)
		{
			propertyName+=GetPropertyName(em,isReplaceId)+"_";
		}
		return propertyName.Trim('_');
	}
}
public int GetSize(EntityMember em)
{
	int size=0;
	if(NativeTypeCSharpSize.ContainsKey(em.Column.NativeType.ToUpper()))
	{
		size= Convert.ToInt32(NativeTypeCSharpSize[em.Column.NativeType]);
	}
	else
	{
       size=em.Column.Size;
	}
	return size;
}
public bool CheckSize(ColumnSchema column)
{
	if(column.Size>0&&(column.NativeType=="varchar"||column.NativeType=="nvarchar"||column.NativeType=="char"||column.NativeType=="nchar"))
	{
		return true;
	}
	return false;
}
 public string GetIdProperty(TableSchema sourceTable,EntityManager entityManager,bool isReplaceId=false)
{
	if(entityManager.AllMembers.Exists(a=>a.ColumnName.ToLower()=="id"))
	{
	   return "";
	}
	if(!sourceTable.HasPrimaryKey||entityManager.PrimaryKey.KeyColumns==null||entityManager.PrimaryKey.KeyColumns.Count==0)
    {
        return "";
    }
	if(entityManager.PrimaryKey.KeyColumns.Count==1)
	{
      string propertyName=GetPropertyName(entityManager.PrimaryKey.KeyColumns[0],isReplaceId);
	  return @" /// <summary>
        /// Unique identifier for this entity.
        /// </summary>"+@"
		public override "+GetSystemTypeName(entityManager.PrimaryKey.KeyColumns[0].Column)+"  Id { get { return "+propertyName+"; } set { "+propertyName+"=value; }}";
	}
    else{
		 return @" /// <summary>
        /// Unique identifier for this entity.
        /// </summary>"+@"
		public override string  Id { get; set;}";
	}
}
public string GetTableDescription(TableSchema sourceTable)
{
    if(sourceTable!=null)
    {
		if(sourceTable.ExtendedProperties!=null&&sourceTable.ExtendedProperties.Count>0)
	    {
			if(sourceTable.ExtendedProperties["description"]!=null)
			{
				return sourceTable.ExtendedProperties["description"].Value.ToString();
			}
			else if(sourceTable.ExtendedProperties["ms_description"]!=null)
			{
				return sourceTable.ExtendedProperties["ms_description"].Value.ToString();
			}
			else if(sourceTable.ExtendedProperties["CS_CreateTableScript"]!=null)
			{
				string script=sourceTable.ExtendedProperties["CS_CreateTableScript"].Value.ToString();
				if(script.IndexOf("COMMENT='")>-1)
				{
					script= script.Substring(script.IndexOf("COMMENT='"));
					string[] tmpArray=script.Split('=');
					if(tmpArray.Length==2)
					{
						 if(tmpArray[1].Length>2)
						 {
							 return tmpArray[1].Substring(1,tmpArray[1].Length-2);
						 }
						 else
						 {							
 					         return tmpArray[1];
					     }
				   }
				}
			}
		}
		return sourceTable.Name;
    }
	else
	{
		return "请先选择数据表";
	}
}
public string GetColumnDefinition(ColumnSchema column,bool isIdentity)
{
    string  columnDefinition=string.Empty;
    switch(column.NativeType.ToUpper())
    {
        case "VARCHAR":
            columnDefinition="VARCHAR("+column.Size+")";
        break;
        case "NVARCHAR":
            columnDefinition="NVARCHAR("+column.Size+")";
            break;
        case "CHAR":
            columnDefinition="CHAR("+column.Size+")";
            break;
        case "NCHAR":
              columnDefinition="NCHAR("+column.Size+")";
            break;   
        default:
            columnDefinition=column.NativeType.ToUpper();
            break;
    }
    if(isIdentity)
    {
        columnDefinition+=" PRIMARY KEY AUTOINCREMENT ";
    }
    if(column.ExtendedProperties["CS_Default"]!=null)
	{		
        string defaultVal=column.ExtendedProperties["CS_Default"].Value.ToString();
		 if(!string.IsNullOrEmpty(defaultVal))
		 {
			 columnDefinition+=" DEFAULT "+defaultVal;
		 }
	}

    if(column.AllowDBNull)columnDefinition+=" NULL";
    else columnDefinition+=" NOT NULL";
    return "columnDefinition =\""+ columnDefinition+"\"";
}
public string GetDefaultValue(ColumnSchema column)
{
    string  typeName=GetSystemTypeName(column); 
    try
    {
        if(column.ExtendedProperties["CS_ColumnDefault"].Value!=null&&column.ExtendedProperties["CS_ColumnDefault"].Value!="")
        {
            if(column.ExtendedProperties["CS_ColumnDefault"].Value.ToString().ToUpper()=="CURRENT_TIMESTAMP"||column.ExtendedProperties["CS_ColumnDefault"].Value.ToString().ToUpper()=="GETDATE()")
            {
               return  "=DateTime.Now";
            }
            string defValue=column.ExtendedProperties["CS_ColumnDefault"].Value.ToString();
            if(!string.IsNullOrEmpty(defValue))
            {
                 switch(typeName)
                 {
                     case "String":
                          defValue="\""+defValue+"\"";
                     break;
                     case "DateTime":
                           if(defValue.Equals("1900-01-01 00:00:00"))
                            {
                                defValue="new DateTime(1900,01,01)";
                            }
                         break;
                     case "Boolean":
                            if(defValue.Equals("B'0'"))
                            {
                               defValue="false";
                            }
                            else if(defValue.Equals("B'1'"))
                            {
                               defValue="true";
                            }
                         break;
                     case "decimal":
                           defValue=defValue+"M";
                         break;
                 }
            }
            return "="+defValue;
        }
    }
    catch(Exception ex)
    {
    }
    string result;
    switch(typeName)
    {
       case "Guid":
             result = " = Guid.Empty";
            break;
        default:
            result = " = default("+typeName+")";
            break;
    }
    return result;
}
public string GetInitialization(ColumnSchema column)
{
	if(column.AllowDBNull)
		return "null";
	
	Type type = column.SystemType;
    //column.NativeType
    //column.DataType
    string result;

    if (type.Equals(typeof(String)))
        result = "String.Empty";
    else if (type.Equals(typeof(DateTime)))
        result = "new DateTime(1900, 1, 1)";
    else if (type.Equals(typeof(Decimal)))
        result = "default(Decimal)";
    else if (type.Equals(typeof(Guid)))
        result = "Guid.Empty";
    else if (type.IsPrimitive)
        result = String.Format("default({0})", type.Name.ToString());
    else
        result = "null";
    return result;
}
public  string GetSystemTypeName(ColumnSchema column)
{
    string result = (this.SystemCSharp.ContainsKey(column.NativeType.ToString()))
       ? this.SystemCSharp[column.NativeType.ToString()]
       : column.NativeType;
     if(column.AllowDBNull)
    {
        if(result.ToUpper()!="string".ToUpper()&&result.ToUpper()!="byte[]".ToUpper())
        {
            result=result+"?";
        }
            
    }
    return result;

}
public bool IsIndex(ColumnSchema column,TableSchema sourceTable)
{
    foreach (IndexSchema indexSchema in sourceTable.Indexes)
    {
        foreach(var item in  indexSchema.MemberColumns)
        {
              if(item.Column==column)
              {
                  return true;
              }
        }
    }
    return false;
}
private MapCollection _keyWords;
public MapCollection GetKeyWords(string baseDirectory)
{
	if (_keyWords == null)
	{
		string path;
		Map.TryResolvePath("CSharpKeyWordEscape", baseDirectory, out path);
		_keyWords = Map.Load(path);
	}
	return _keyWords;
}

private NamingProperty namingConventions;
public NamingProperty GetNamingConventions(TableNamingEnum tableNaming,EntityNamingEnum entityNaming)
{ 
  if(namingConventions==null)
  {
	namingConventions= new NamingProperty();
  }
  namingConventions.TableNaming=tableNaming;
  namingConventions.EntityNaming=entityNaming;
  return namingConventions;
}
/// <summary>
/// 
/// </summary>
public enum TableMapAttributeEnum
{
	LiteMap,
    FullMap
}
 public bool IncludeColumn(EntityMember em)
 {
    return !InArray(em.ColumnName,"CreateTime,CreateUser,UpdateTime,UpdateUser,DeleteFlag,DeleteTime,DeleteUser")
         &&!em.ColumnName.ToLower().Contains("idpath")&&!em.ColumnName.ToLower().Contains("namepath");
 }
/// <summary>
/// 判断指定字符串在指定字符串数组中的位置
/// </summary>
/// <param name="strSearch">字符串</param>
/// <param name="stringArray">字符串数组</param>
/// <param name="caseInsensetive">是否不区分大小写, true为不区分, false为区分</param>
/// <returns>字符串在指定字符串数组中的位置, 如不存在则返回-1</returns>
public  int GetInArrayID(string strSearch, string[] stringArray, bool caseInsensetive)
{
    for (int i = 0; i < stringArray.Length; i++)
    {
        if (caseInsensetive)
        {
            if (strSearch.ToLower() == stringArray[i].ToLower())
            {
                return i;
            }
        }
        else
        {
            if (strSearch == stringArray[i])
            {
                return i;
            }
        }

    }
    return -1;
}
/// <summary>
/// 判断指定字符串在指定字符串数组中的位置
/// </summary>
/// <param name="strSearch">字符串</param>
/// <param name="stringArray">字符串数组</param>
/// <returns>字符串在指定字符串数组中的位置, 如不存在则返回-1</returns>		
public  int GetInArrayID(string strSearch, string[] stringArray)
{
    return GetInArrayID(strSearch, stringArray, true);
}

/// <summary>
/// 判断指定字符串是否属于指定字符串数组中的一个元素
/// </summary>
/// <param name="strSearch">字符串</param>
/// <param name="stringArray">字符串数组</param>
/// <param name="caseInsensetive">是否不区分大小写, true为不区分, false为区分</param>
/// <returns>判断结果</returns>
public  bool InArray(string strSearch, string[] stringArray, bool caseInsensetive)
{
    return GetInArrayID(strSearch, stringArray, caseInsensetive) >= 0;
}

/// <summary>
/// 判断指定字符串是否属于指定字符串数组中的一个元素
/// </summary>
/// <param name="str">字符串</param>
/// <param name="stringarray">字符串数组</param>
/// <returns>判断结果</returns>
public  bool InArray(string str, string[] stringarray)
{
    return InArray(str, stringarray, false);
}

/// <summary>
/// 判断指定字符串是否属于指定字符串数组中的一个元素
/// </summary>
/// <param name="str">字符串</param>
/// <param name="stringarray">内部以逗号分割单词的字符串</param>
/// <returns>判断结果</returns>
public  bool InArray(string str, string stringarray)
{
    return InArray(str, SplitString(stringarray, ","), false);
}

/// <summary>
/// 判断指定字符串是否属于指定字符串数组中的一个元素
/// </summary>
/// <param name="str">字符串</param>
/// <param name="stringarray">内部以逗号分割单词的字符串</param>
/// <param name="strsplit">分割字符串</param>
/// <returns>判断结果</returns>
public  bool InArray(string str, string stringarray, string strsplit)
{
    return InArray(str, SplitString(stringarray, strsplit), false);
}

/// <summary>
/// 判断指定字符串是否属于指定字符串数组中的一个元素
/// </summary>
/// <param name="str">字符串</param>
/// <param name="stringarray">内部以逗号分割单词的字符串</param>
/// <param name="strsplit">分割字符串</param>
/// <param name="caseInsensetive">是否不区分大小写, true为不区分, false为区分</param>
/// <returns>判断结果</returns>
public  bool InArray(string str, string stringarray, string strsplit, bool caseInsensetive)
{
    return InArray(str, SplitString(stringarray, strsplit), caseInsensetive);
}


/// <summary>
/// 分割字符串
/// </summary>
public  string[] SplitString(string strContent, string strSplit)
{
    if (!string.IsNullOrEmpty(strContent))
    {
        if (strContent.IndexOf(strSplit) < 0)
        {
            string[] tmp = { strContent };
            return tmp;
        }
        return Regex.Split(strContent, Regex.Escape(strSplit), RegexOptions.IgnoreCase);
    }
    else
    {
        return new string[0] { };
    }
}

/// <summary>
/// 分割字符串
/// </summary>
/// <returns></returns>
public  string[] SplitString(string strContent, string strSplit, int count)
{
    string[] result = new string[count];

    string[] splited = SplitString(strContent, strSplit);

    for (int i = 0; i < count; i++)
    {
        if (i < splited.Length)
            result[i] = splited[i];
        else
            result[i] = string.Empty;
    }

    return result;
}
/// <summary>
/// 
/// </summary>
/// <param name="column"></param>
/// <returns></returns>
public string GetPolymorphMethod(ColumnSchema column)
{
	if(column.Name.ToLower()=="id")
	{
		return "override";
	}
	return "virtual";
}