This project contains a sample of using CodeSmith Generator Project files inside of Visual Studio 2010.  
You can right-click on the .csp files and a context menu will come up to allow you to manage the outputs and generate the outputs of the project.  
Under the Output Options, there are several options that you can set to control the behavior of the project file.

You can also use the CodeSmith Generator Project files from Windows Explorer or from the cs.exe console client.