Contributed by:
Michael Toscano, Geoff McElhanon and Blake Niemyjski