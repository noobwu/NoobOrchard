//------------------------------------------------------------------------------
//
// Copyright (c) 2002-2012 CodeSmith Tools, LLC.  All rights reserved.
//
// The terms of use for this software are contained in the file
// named sourcelicense.txt, which can be found in the root of this distribution.
// By using this software in any fashion, you are agreeing to be bound by the
// terms of this license.
//
// You must not remove this notice, or any other, from this software.
//
// Credits:
//     Queries were written by Steve Hyde <sbhyde@onnx.com>.
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Text;
using iAnywhere.Data.SQLAnywhere;

namespace SchemaExplorer
{
    /// <summary>
    /// SQLAnywhere Schema Provider
    /// </summary>
    public class SQLAnywhereSchemaProvider : IDbSchemaProvider
    {
        #region Private Members

        private readonly string _connectionString;

        #endregion

        #region Constructor(s)

        /// <summary>
        /// SQLAnywhere Schema Provider
        /// </summary>
        public SQLAnywhereSchemaProvider()
        {
        }

        /// <summary>
        /// SQLAnywhere Schema Provider
        /// </summary>
        public SQLAnywhereSchemaProvider(string connectionString)
        {
            _connectionString = connectionString;
        }

        #endregion

        #region Properties

        #region IDbConnectionStringEditor Members

        /// <summary>
        /// Connection String
        /// </summary>
        public string ConnectionString
        {
            get { return _connectionString; }
        }

        /// <summary>
        /// Connection Editor
        /// </summary>
        public bool EditorAvailable
        {
            get { return true; }
        }

        #endregion

        #region IDbSchemaProvider Members

        /// <summary>
        /// Return the Constant name of the SchemaProvider.
        /// </summary>
        public string Name
        {
            get { return "SQLAnywhereSchemaProvider"; }
        }

        /// <summary>
        /// Returns the name of the SchemaProvider.
        /// </summary>
        public string Description
        {
            get { return "SQLAnywhere Schema Provider"; }
        }

        #endregion

        #endregion

        #region Table Retrieval Methods

        #region public TableSchema[] GetTables( string connectionString, DatabaseSchema database )

        /// <summary>
        /// Get the Array of tables...
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="database"></param>
        /// <returns></returns>
        public TableSchema[] GetTables(string connectionString, DatabaseSchema database)
        {
            var tableList = new List<TableSchema>();
            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                const string sql =
                    @"SELECT USER_NAME(t.Creator) owner, t.table_name name, o.creation_time creation, t.Creator, k.remarks remarks from sys.SYSTAB t JOIN sys.SYSOBJECT o ON t.object_id = o.object_id LEFT OUTER JOIN sys.SYSREMARK k ON k.object_id = t.object_id WHERE t.table_type = 1 AND t.Creator in (USER_ID('dba'), user_id()) ORDER BY 1,2";
                using (var command = new SACommand(sql, connection))
                {
                    using (SADataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            string remarks = "";
                            if (!Convert.IsDBNull(reader["remarks"]))
                            {
                                remarks = Convert.ToString(reader["remarks"]);
                            }

                            var extendedProperties = new List<ExtendedProperty>
                                                         {
                                                             new ExtendedProperty(ExtendedPropertyNames.Description, remarks, DbType.String)
                                                         };

                            tableList.Add(new TableSchema(database, reader["name"].ToString(),
                                                          reader["owner"].ToString(),
                                                          DateTime.Parse(reader["creation"].ToString()),
                                                          extendedProperties.ToArray()));
                        }
                    }
                }
            }

            return tableList.ToArray();
        }

        #endregion

        #region public IndexSchema[] GetTableIndexes( string connectionString, TableSchema table )

        /// <summary>
        /// Get all the Indexes for a given Table
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <returns></returns>
        /// 
        public IndexSchema[] GetTableIndexes(string connectionString, TableSchema table)
        {
            // This code is greatly simplified in that you are calling it with a table name. This means that many of the
            //   extra conditions present in the where clause above are not needed.

            string sql =
                string.Format(
                    @"SELECT USER_NAME(t.Creator) as owner,
                                t.table_name tablename,
                                i.index_name indexname,
                                CASE WHEN (t.clustered_index_id = i.index_id) THEN 'clustered' ELSE 'non-clustered' END IsClustered,
                                CASE WHEN (i.""unique"" < 3) THEN 'unique' ELSE 'non-unique' END IsUnique,
                                f.dbspace_name segment,
                                
                               (select list(c.column_name, ' ' order by l.sequence asc) 
                                    from SYS.SYSIDXCOL l join SYS.SYSTABCOL c on (c.table_id = l.table_id and c.column_id = l.column_id)
                                    where l.index_id = i.index_id and l.table_id = i.table_id) as colnames
                                 
                            FROM sys.SYSTAB t JOIN sys.SYSIDX i ON t.table_id = i.table_id JOIN sys.SYSFILE f ON i.file_id = f.file_id
                            WHERE i.index_category > 1
                                AND t.table_name='{0}' 
                                AND t.Creator = user_id('{1}')
                            ORDER BY 1,2,3",
                    table.Name, table.Owner);

            var indexSchemas = new List<IndexSchema>();
            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                using (var command = new SACommand(sql, connection))
                {
                    using (SADataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            string indexType = reader["IsUnique"].ToString();
                            string[] colNames = reader["colnames"].ToString().Trim().Split(' '); // .Split(',');
                            int i = 0;
                            foreach (string cname in colNames)
                            {
                                colNames[i] = cname.Split(" ".ToCharArray())[0];
                                i++;
                            }
                            var schema = new IndexSchema(
                                table,
                                reader["indexname"].ToString(),
                                false,
                                (indexType == "unique"),
                                false,
                                colNames);

                            indexSchemas.Add(schema);
                        }
                    }
                }
            }

            // Return the array of indexes
            return indexSchemas.ToArray();
        }

        #endregion

        #region public ColumnSchema[] GetTableColumns( string connectionString, TableSchema table )

        /// <summary>
        /// Return the Columns for a given Table.
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <returns></returns>
        public ColumnSchema[] GetTableColumns(string connectionString, TableSchema table)
        {
            var columnList = new List<ColumnSchema>();
            //const int userDefinedStart = 100;
            string sql =
                string.Format(
                    @"SELECT c.column_name name, c.user_type usertype, c.scale scale , c.width prec , 
                        C.width length, (CASE c.nulls WHEN 'Y' THEN 1 ELSE 0 END) CanBeNull, d.domain_name datatype, 
                        c.""default"" RowDefault, 
                        (CASE WHEN RowDefault = 'AUTOINCREMENT' OR RowDefault = 'IDENTITY' OR RowDefault = 'GLOBAL AUTOINCREMENT' 
                                THEN 1 ELSE 0 END) IsIdentity, k.remarks remarks

                        FROM sys.SYSTAB t JOIN sys.SYSTABCOL c ON t.table_id = c.table_id JOIN sys.SYSDOMAIN d ON c.domain_id = d.domain_id LEFT OUTER JOIN sys.SYSREMARK k ON k.object_id = c.object_id
 
                        WHERE t.table_name = '{0}'
                        AND t.Creator = user_id('{1}')
                        ORDER by C.column_id",
                    table.Name, table.Owner);

            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                // Get all the tables
                var adapter = new SADataAdapter(sql, connection);
                var dataSet = new DataTable();
                adapter.Fill(dataSet);

                // Iterate through the results
                foreach (DataRow row in dataSet.Rows)
                {
                    byte precision = 0;

                    if (!Convert.IsDBNull(row["prec"]))
                    {
                        //System.Diagnostics.Debug.WriteLine(table.Name + ' ' + row["prec"]);
                        if (Convert.ToUInt32(row["prec"]) <= 255)
                        {
                            precision = Convert.ToByte(row["prec"]);
                        }
                    }

                    //Sybase seeds the identity at 1 always
                    Int16 isIdentity = Convert.ToInt16(row["IsIdentity"]);
                    int identitySeed;
                    int identityIncrement;
                    if (isIdentity == 1)
                    {
                        identitySeed = 1;
                        identityIncrement = 1;
                    }
                    else
                    {
                        identitySeed = 0;
                        identityIncrement = 0;
                    }

                    //replace user-defined data types with native data types
                    string sDataType = (string) row["datatype"];

                    string remarks = "";
                    if (!Convert.IsDBNull(row["remarks"]))
                    {
                        remarks = Convert.ToString(row["remarks"]);
                    }


                    var extendedProperties = new List<ExtendedProperty>
                                                 {
                                                     new ExtendedProperty(ExtendedPropertyNames.DefaultValue, row["RowDefault"], DbType.String),
                                                     new ExtendedProperty(ExtendedPropertyNames.IsIdentity, isIdentity == 1, DbType.Boolean),
                                                     new ExtendedProperty(ExtendedPropertyNames.IdentitySeed, identitySeed, DbType.Int32),
                                                     new ExtendedProperty(ExtendedPropertyNames.IdentityIncrement, identityIncrement, DbType.Int32),
                                                     new ExtendedProperty(ExtendedPropertyNames.Description, remarks, DbType.String),
                                                     new ExtendedProperty(ExtendedPropertyNames.IsRowGuidColumn, false, DbType.Boolean),
                                                     new ExtendedProperty(ExtendedPropertyNames.IsComputed, false, DbType.Boolean),
                                                     new ExtendedProperty(ExtendedPropertyNames.IsDeterministic, true, DbType.Boolean)
                                                 };

                    var column = new ColumnSchema(
                        table,
                        (string) row["name"],
                        GetDbTypeFromRow(row, sDataType),
                        sDataType,
                        Convert.ToInt32(row["length"]),
                        precision,
                        row.IsNull("scale") ? 0 : Convert.ToInt32(row["scale"]),
                        Convert.ToBoolean(row["CanBeNull"]),
                        extendedProperties.ToArray());

                    columnList.Add(column);
                }
            }

            // Return the array of columns
            return columnList.ToArray();
        }

        #endregion

        #region public TableKeySchema[] GetTableKeys( string connectionString, TableSchema table )

        /// <summary>
        /// Return the Foreign key info for a given table...
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <returns></returns>
        public TableKeySchema[] GetTableKeys(string connectionString, TableSchema table)
        {
            var tableSchemaList = new List<TableKeySchema>();
            var foreignKeyMemberCollection = new NameValueCollection();
            var primaryKeyMemberCollection = new NameValueCollection();
            var relatedTablesByConstraintName = new Hashtable();

            var sql =
                string.Format(
                    @"SELECT 
                    tfk.table_name FK_TABLE_NAME,     
                    tpk.table_name PK_TABLE_NAME, 
                    fkc.column_name FK_COLUMN_NAME,
                    pkc.column_name PK_COLUMN_NAME,
                    x.index_name CONSTRAINT_NAME

                    FROM sys.SYSTAB tfk JOIN sys.SYSIDX x ON tfk.table_id = x.table_id 
                      JOIN sys.SYSIDXCOL c ON c.table_id = x.table_id AND c.index_id = x.index_id
                      JOIN sys.SYSTABCOL fkc ON tfk.table_id = fkc.table_id AND fkc.column_id = c.column_id
                      JOIN sys.SYSFKEY y ON y.foreign_table_id = tfk.table_id AND y.foreign_index_id = x.index_id
                      JOIN sys.SYSTAB tpk ON y.primary_table_id = tpk.table_id
                      JOIN sys.SYSTABCOL pkc ON tpk.table_id = pkc.table_id AND pkc.column_id = c.primary_column_id

                    WHERE x.index_Category = 2
                        AND tfk.table_name = '{0}'
                        AND tfk.Creator = user_id('{1}')",
                    table.Name, table.Owner);

            using (var connection = new SAConnection(connectionString))
            {
                connection.Open();
                using (var command = new SACommand(sql, connection))
                {
                    using (SADataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            foreignKeyMemberCollection.Add((string) reader["CONSTRAINT_NAME"],
                                                           (string) reader["FK_COLUMN_NAME"]);
                            primaryKeyMemberCollection.Add((string) reader["CONSTRAINT_NAME"],
                                                           (string) reader["PK_COLUMN_NAME"]);
                            relatedTablesByConstraintName[reader["CONSTRAINT_NAME"]] = reader["PK_TABLE_NAME"];
                        }
                    }
                }
            }

            if (foreignKeyMemberCollection.Count > 0)
            {
                tableSchemaList.AddRange(foreignKeyMemberCollection.AllKeys.Select(constraintName =>
                                                                                   new TableKeySchema(
                                                                                       table.Database,
                                                                                       constraintName,
                                                                                       foreignKeyMemberCollection.GetValues(constraintName),
                                                                                       table.Name,
                                                                                       primaryKeyMemberCollection.GetValues(constraintName),
                                                                                       (string)relatedTablesByConstraintName[constraintName])));
            }

            return tableSchemaList.ToArray();
        }

        #endregion

        #region public PrimaryKeySchema GetTablePrimaryKey( string connectionString, TableSchema table )

        /// <summary>
        /// Return the PK for a given Table...
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <returns></returns>
        public PrimaryKeySchema GetTablePrimaryKey(string connectionString, TableSchema table)
        {
            PrimaryKeySchema primaryKeySchema = null;
            var sql =
                string.Format(
                    @"SELECT 
                    c.column_name column_name

                    FROM sys.SYSTAB t JOIN sys.SYSIDX x ON t.table_id = x.table_id 
                      JOIN sys.SYSIDXCOL i ON i.table_id = x.table_id AND i.index_id = x.index_id
                      JOIN sys.SYSTABCOL c ON t.table_id = c.table_id AND c.column_id = i.column_id

                    WHERE x.index_Category = 1
                        AND t.table_name = '{0}'
                        AND t.Creator = user_id('{1}')",
                    table.Name, table.Owner);

            var members = new List<string>();
            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                using (var command = new SACommand(sql, connection))
                {
                    using (var reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            members.Add(reader.GetString(reader.GetOrdinal("column_name")));
                        }
                    }
                }
            }

            if (members.Count > 0)
                primaryKeySchema = new PrimaryKeySchema(table, string.Format("PK_{0}", table.Name), members.ToArray());

            return primaryKeySchema;
        }

        #endregion

        #region public DataTable GetTableData( string connectionString, TableSchema table )

        /// <summary>
        /// Return the data from a table in a System.DataTable object...
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <returns></returns>
        public DataTable GetTableData(string connectionString, TableSchema table)
        {
            using (var connection = new SAConnection(connectionString))
            {
                // Create and fill the data table
                var dataTable = new DataTable(table.Name);

                string sql = string.Format("SELECT * FROM {0}", table.Name);

                using (var dataAdapter = new SADataAdapter(sql, connection))
                {
                    dataAdapter.Fill(dataTable);
                }

                return dataTable;
            }
        }

        #endregion

        #endregion

        #region Extended Properties

        #region public void SetExtendedProperties( string connectionString, SchemaObjectBase schemaObject )

        /// <summary>
        /// Sets an extended property
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="schemaObject"></param>
        /// <exception cref="NotImplementedException"></exception>
        public void SetExtendedProperties(string connectionString, SchemaObjectBase schemaObject)
        {
            throw new NotImplementedException("Extended Properties have not been implemented.");
        }

        #endregion

        #region public ExtendedProperty[] GetExtendedProperties(string connectionString, SchemaObjectBase schemaObject)

        /// <summary>
        /// Returns an array of extended properties
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="schemaObject"></param>
        /// <returns></returns>
        public ExtendedProperty[] GetExtendedProperties(string connectionString, SchemaObjectBase schemaObject)
        {
            return new ExtendedProperty[0];
        }

        #endregion

        #endregion

        #region View Retrieval Methods

        #region public ViewSchema[] GetViews( string connectionString, DatabaseSchema database )

        /// <summary>
        /// Return array of Views
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="database"></param>
        /// <returns></returns>
        public ViewSchema[] GetViews(string connectionString, DatabaseSchema database)
        {
            const string sql = @"SELECT USER_NAME(t.Creator) owner, t.table_name name, o.creation_time creation, t.Creator, k.remarks remarks from sys.SYSTAB t JOIN sys.SYSOBJECT o ON t.object_id = o.object_id LEFT OUTER JOIN sys.SYSREMARK k ON k.object_id = t.object_id WHERE t.table_type in (2, 21) AND t.Creator in (USER_ID('dba'), user_id()) ORDER BY 1,2";
            var viewList = new List<ViewSchema>();

            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                using (var command = new SACommand(sql, connection))
                {
                    using (SADataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            string remarks = "";
                            if (!Convert.IsDBNull(reader["remarks"]))
                            {
                                remarks = Convert.ToString(reader["remarks"]);
                            }

                            var extendedProperties = new List<ExtendedProperty>
                                                         {
                                                             new ExtendedProperty(ExtendedPropertyNames.Description, remarks, DbType.String)
                                                         };

                            viewList.Add(new ViewSchema(database, reader["name"].ToString(), reader["owner"].ToString(),
                                                        DateTime.Parse(reader["creation"].ToString()),
                                                        extendedProperties.ToArray()));
                        }
                    }
                }
            }

            return viewList.ToArray();
        }

        #endregion

        #region public string GetViewText( string connectionString, ViewSchema view )

        /// <summary>
        /// Returns the Text of a View's definition
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="view"></param>
        /// <returns></returns>
        public string GetViewText(string connectionString, ViewSchema view)
        {
            string viewText;

            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                string sql = string.Format("sp_helptext '{0}.{1}'", view.Owner, view.Name);
                using (var command = new SACommand(sql, connection))
                {
                    viewText = (string) command.ExecuteScalar();
                }
            }

            return viewText;
        }

        #endregion

        #region public ViewColumnSchema[] GetViewColumns( string connectionString, ViewSchema view )

        /// <summary>
        /// Return all the columns for a view...
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="view"></param>
        /// <returns></returns>
        public ViewColumnSchema[] GetViewColumns(string connectionString, ViewSchema view)
        {
            var columnList = new List<ViewColumnSchema>();

            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                //const int userDefinedStart = 100;

                string sql =
                    string.Format(
                        @"SELECT c.column_name name, c.user_type usertype, c.scale scale , c.width prec , 
                        C.width length, (CASE c.nulls WHEN 'Y' THEN 1 ELSE 0 END) CanBeNull, d.domain_name datatype, 
                        c.""default"" RowDefault, 
                        (CASE WHEN RowDefault = 'AUTOINCREMENT' OR RowDefault = 'IDENTITY' OR RowDefault = 'GLOBAL AUTOINCREMENT' 
                                THEN 1 ELSE 0 END) IsIdentity, k.remarks remarks

                        FROM sys.SYSTAB t JOIN sys.SYSTABCOL c ON t.table_id = c.table_id JOIN sys.SYSDOMAIN d ON c.domain_id = d.domain_id LEFT OUTER JOIN sys.SYSREMARK k ON k.object_id = c.object_id
 
                        WHERE t.table_name = '{0}'
                        AND t.Creator = user_id('{1}')
                        ORDER by C.column_id",
                        view.Name, view.Owner);


                using (var command = new SACommand(sql, connection))
                {
                    using (SADataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            //int precision = !reader.IsDBNull(4) ? Convert.ToInt32(reader["prec"]) : 0;
                            byte precision = 0;
                            if (!Convert.IsDBNull(reader["prec"]))
                            {
                                //System.Diagnostics.Debug.WriteLine(table.Name + ' ' + row["prec"]);
                                if (Convert.ToUInt32(reader["prec"]) <= 255)
                                {
                                    precision = Convert.ToByte(reader["prec"]);
                                }
                            }

                            //int scale = !reader.IsDBNull(2) ? Convert.ToInt32(reader["scale"]) : 0;
                            int scale = 0;
                            if (!Convert.IsDBNull(reader["scale"]))
                            {
                                scale = Convert.ToInt32(reader["scale"]);
                            }

                            //replace user-defined data types with native data types
                            string sDataType = (string) reader["datatype"];

                            string remarks = "";
                            if (!Convert.IsDBNull(reader["remarks"]))
                            {
                                remarks = Convert.ToString(reader["remarks"]);
                            }

                            var extendedProperties = new List<ExtendedProperty>
                                                         {
                                                             new ExtendedProperty(ExtendedPropertyNames.Description, remarks, DbType.String)
                                                         };

                            columnList.Add(
                                new ViewColumnSchema(
                                    view,
                                    reader["name"].ToString(),
                                    GetDbType(sDataType, precision, scale),
                                    sDataType,
                                    Convert.ToInt32(reader["length"]),
                                    precision,
                                    scale,
                                    false,
                                    extendedProperties.ToArray()
                                    )
                                );
                        }
                    }
                }
            }

            // Return the array of columns
            return columnList.ToArray();
        }

        #endregion

        #region public DataTable GetViewData( string connectionString, ViewSchema view )

        /// <summary>
        /// Return all the Rows from a view
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="view"></param>
        /// <returns></returns>
        public DataTable GetViewData(string connectionString, ViewSchema view)
        {
            // Open a connection
            using (var connection = new SAConnection(connectionString))
            {
                // Create and fill the data table
                var dataTable = new DataTable(view.Name);

                string sql = string.Format("SELECT * FROM {0}.{1}", view.Owner, view.Name);
                using (var dataAdapter = new SADataAdapter(sql, connection))
                {
                    dataAdapter.Fill(dataTable);
                }

                return dataTable;
            }
        }

        #endregion

        #endregion

        #region Command Retrieval Methods

        #region public CommandSchema[] GetCommands( string connectionString, DatabaseSchema database )

        /// <summary>
        /// Return array of commands...
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="database"></param>
        /// <returns></returns>
        public CommandSchema[] GetCommands(string connectionString, DatabaseSchema database)
        {
            const string sql = "SELECT USER_NAME(t.creator) owner, t.proc_name name, o.creation_time creation, k.remarks remarks FROM sys.SYSPROCEDURE t JOIN sys.SYSOBJECT o ON t.object_id = o.object_id LEFT OUTER JOIN sys.SYSREMARK k ON k.object_id = t.object_id WHERE t.source IS NOT NULL AND t.Creator in (USER_ID('dba'),USER_ID('dbo'), user_id()) ORDER BY 1,2";

            var commandList = new List<CommandSchema>();
            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                using (var command = new SACommand(sql, connection))
                {
                    using (SADataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            string remarks = "";
                            if (!Convert.IsDBNull(reader["remarks"]))
                            {
                                remarks = Convert.ToString(reader["remarks"]);
                            }

                            var extendedProperties = new List<ExtendedProperty>
                                                         {
                                                             new ExtendedProperty(ExtendedPropertyNames.Description, remarks, DbType.String, PropertyStateEnum.ReadOnly)
                                                         };

                            commandList.Add(new CommandSchema(database, reader["name"].ToString(),
                                                              reader["owner"].ToString(),
                                                              DateTime.Parse(reader["creation"].ToString()),
                                                              extendedProperties.ToArray()));
                        }
                    }
                }
            }

            // Return the array of commands
            return commandList.ToArray();
        }

        #endregion

        #region public ParameterSchema[] GetCommandParameters( string connectionString, CommandSchema command )

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public ParameterSchema[] GetCommandParameters(string connectionString, CommandSchema command)
        {
            var paramList = new List<ParameterSchema>();

            //const int userDefinedStart = 100;

            using (var connection = new SAConnection(connectionString))
            {
                // Open a connection
                connection.Open();

                string sql =
                    string.Format(
                        @"SELECT c.parm_name name, c.scale scale, c.width prec, c.width length, d.domain_name datatype, c.parm_mode_in, c.user_type usertype, c.parm_mode_out
                            FROM sys.SYSPROCEDURE p JOIN sys.SYSPROCPARM c ON p.proc_id = c.proc_id JOIN sys.SYSDOMAIN d ON c.domain_id = d.domain_id
                            WHERE p.proc_name = '{0}'
                                AND USER_NAME(p.creator) = '{1}'
                            ORDER BY c.parm_id ",
                        command.Name, command.Owner);

                using (var saCommand = new SACommand(sql, connection))
                {
                    using (SADataReader reader = saCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string name = reader.IsDBNull(0) ? "" : reader.GetString(0);
                            string datatype = reader.IsDBNull(4) ? "" : reader.GetString(4);
                            int scale = reader.IsDBNull(1) ? 0 : reader.GetInt32(1);

                            //int precision = reader.IsDBNull(2) ? 0 : reader.GetInt32(2);
                            byte precision = 0;
                            if (!Convert.IsDBNull(reader["prec"]))
                            {
                                //System.Diagnostics.Debug.WriteLine(table.Name + ' ' + row["prec"]);
                                if (Convert.ToUInt32(reader["prec"]) <= 255)
                                {
                                    precision = Convert.ToByte(reader["prec"]);
                                }
                            }

                            int length = reader.IsDBNull(3) ? 0 : reader.GetInt32(3);

                            ParameterDirection direction = ParameterDirection.Input;
                            if (reader.GetString(5) == "Y")
                            {
                                if (reader.GetString(7) == "Y")
                                {
                                    direction = ParameterDirection.InputOutput;
                                }
                            }
                            else
                            {
                                direction = ParameterDirection.Output;
                                if (reader.GetString(7) == "N")
                                {
                                    direction = ParameterDirection.ReturnValue;
                                }
                            }

                            var dbType = GetDbType(datatype, length, scale);
                            var extendedProperties = new List<ExtendedProperty>
                                                         {
                                                             new ExtendedProperty(ExtendedPropertyNames.DefaultValue, string.Empty, dbType, PropertyStateEnum.ReadOnly)
                                                         };

                            paramList.Add(new ParameterSchema(command,
                                                              name,
                                                              direction,
                                                              GetDbType(datatype, length, scale),
                                                              datatype,
                                                              length,
                                                              Convert.ToByte(precision),
                                                              scale,
                                                              false,
                                                              extendedProperties.ToArray()));
                        }
                    }
                }
            }

            return paramList.ToArray();
        }

        #endregion

        #region public CommandResultSchema[] GetCommandResultSchemas( string connectionString, CommandSchema command )

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public CommandResultSchema[] GetCommandResultSchemas(string connectionString, CommandSchema command)
        {
            throw new NotImplementedException("CommandResultSchemas has not been implemented.");
        }

        #endregion

        #region public string GetCommandText( string connectionString, CommandSchema command )

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public string GetCommandText(string connectionString, CommandSchema command)
        {
            string sql = string.Format("sp_helptext '{0}.{1}'", command.Owner, command.Name);

            var source = new StringBuilder();
            using (var connection = new SAConnection(connectionString))
            {
                connection.Open();
                using (var saCommand = new SACommand(sql, connection))
                {
                    using (SADataReader reader = saCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            if (!reader.IsDBNull(0))
                                source.AppendLine(reader.GetString(0));
                        }
                    }
                }

                // Close the connection.
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }

            return source.ToString();
        }

        #endregion

        #endregion

        #region Misc. Methods

        /// <summary>
        /// Get Database Name
        /// </summary>
        public string GetDatabaseName(string connectionString)
        {
            // Open a connection
            using (var connection = new SAConnection(connectionString))
            {
                connection.Open();
                return connection.Database;
            }
        }

        private static DbType GetDbTypeFromRow(DataRow row, string nativeType)
        {
            //same proc as above, but the nativeType is passed in

            int scale = Convert.ToInt32(row["scale"]);
            int precision = Convert.ToInt32(row.IsNull("prec") ? row["width"] : row["prec"]);

            return GetDbType(nativeType, precision, scale);
        }

        private static DbType GetDbType(string nativeType, int precision, int scale)
        {
            #region Comments

            // DB Datatypes         Percision
            //smallint               5  
            //integer                10 
            //numeric                   
            //float                  7  
            //double                 15 
            //date                      
            //char                      
            //char                      
            //varchar                   
            //long varchar              
            //binary                    
            //long binary               
            //timestamp                 
            //time                      
            //tinyint                3  
            //bigint                 20 
            //unsigned int           10 
            //unsigned smallint      5  
            //unsigned bigint        21 
            //bit                    1  
            //decimal                   
            //varbinary                 
            //uniqueidentifier          
            //varbit                    
            //long varbit               
            //xml                       
            //nchar                     
            //nchar                     
            //nvarchar                  
            //long nvarchar             

            #endregion

            switch (nativeType.ToUpper())
            {
                case "FLOAT":
                    if (precision <= 7)
                    {
                        return DbType.Single;
                    }
                    return DbType.Double;

                case "DOUBLE":
                    return DbType.Double;

                case "BITINT":
                    return DbType.Int64;

                case "UNSIGNED BIGINT":
                    return DbType.UInt64;

                case "UNSIGNED INT":
                    return DbType.UInt32;

                case "UNSIGNED SMALLINT":
                    return DbType.UInt16;

                case "INTEGER":
                    return DbType.Int32;

                case "TINYINT":
                    return DbType.Byte;

                case "SMALLINT":
                    return DbType.Int16;

                case "BIT":
                    return DbType.Boolean;

                case "NUMERIC":
                case "DECIMAL":
                    //if ( scale > 0 && scale != 255 )
                    //{
                    //    // Real number
                    // If the designer defined this a NUMERIC or DECIMAL, then that is the way to treat it. KISS
                    if (precision > 28)
                    {
                        return DbType.VarNumeric; // Should be DbType.Decimal? - Is OK I think!
                    }

                    return DbType.Decimal;
                    //}

                case "UNIQUEIDENTIFIER":
                    return DbType.Guid;

                case "TIME":
                case "TIMESTAMP":
                    return DbType.DateTime;
                case "DATE":
                    return DbType.Date;

                case "VARBIT":
                case "LONG VARBIT":
                    return DbType.Object;

                case "LONG VARCHAR":
                case "VARCHAR":
                    return DbType.String;

                case "CHAR":
                    return DbType.StringFixedLength;

                case "NCHAR":
                case "LONG NVARCHAR":
                    return DbType.String;

                case "XML":
                    return DbType.Xml;

                case "VARBINARY":
                case "BINARY":
                case "LONG BINARY":
                    return DbType.Object;

                default:
                    return DbType.Object;
            }
        }

        #endregion
    }
}