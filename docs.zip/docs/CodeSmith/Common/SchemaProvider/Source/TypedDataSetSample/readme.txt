This project contains a test application for the typed DataSet templates.

** NOTE: These templates are a work in progress.