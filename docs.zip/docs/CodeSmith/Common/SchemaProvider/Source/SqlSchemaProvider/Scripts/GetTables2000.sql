SELECT
  object_name(so.id) AS [OBJECT_NAME],
  user_name(so.uid)  AS [USER_NAME],
  so.type            AS TYPE,
  so.crdate          AS DATE_CREATED,
  fg.file_group      AS FILE_GROUP,
  so.id              AS [OBJECT_ID]
FROM 
  dbo.sysobjects so
LEFT JOIN (
    SELECT 
        s.groupname AS file_group,
        i.id        AS id
    FROM dbo.sysfilegroups s
    INNER JOIN dbo.sysindexes i
        ON i.groupid = s.groupid 
    WHERE i.indid < 2                           
  ) AS fg
  ON so.id = fg.id
WHERE
  so.type = N'U'
  AND permissions(so.id) & 4096 <> 0
  AND ObjectProperty(so.id, N'IsMSShipped') = 0
ORDER BY user_name(so.uid), object_name(so.id)