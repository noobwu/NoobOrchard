SELECT
	object_name(so.id)		AS [OBJECT_NAME],
	schema_name(so.uid)		AS [USER_NAME],
	so.type					AS TYPE,
	so.crdate				AS DATE_CREATED,
	fg.file_group			AS FILE_GROUP,
	so.id					as [OBJECT_ID]
FROM 
	dbo.sysobjects so
	LEFT JOIN (
		SELECT 
			s.groupname AS file_group,
			i.id        AS id
		FROM dbo.sysfilegroups s
			INNER JOIN dbo.sysindexes i
			ON i.groupid = s.groupid 
		WHERE i.indid < 2                           
	) AS fg
	ON so.id = fg.id
WHERE
	so.type = N'U'
	AND permissions(so.id) & 4096 <> 0
	AND ObjectProperty(so.id, N'IsMSShipped') = 0
	AND NOT EXISTS (SELECT * FROM sys.extended_properties WHERE major_id = so.id AND name = 'microsoft_database_tools_support' AND value = 1)
ORDER BY schema_name(so.uid), object_name(so.id)