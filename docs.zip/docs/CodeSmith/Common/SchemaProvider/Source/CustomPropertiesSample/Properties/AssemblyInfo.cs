﻿//------------------------------------------------------------------------------
//
// Copyright (c) 2002-2012 CodeSmith Tools, LLC.  All rights reserved.
// 
// The terms of use for this software are contained in the file
// named sourcelicense.txt, which can be found in the root of this distribution.
// By using this software in any fashion, you are agreeing to be bound by the
// terms of this license.
// 
// You must not remove this notice, or any other, from this software.
//
//------------------------------------------------------------------------------

using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CodeSmith Generator Samples")]
[assembly: AssemblyDescription("CodeSmith Generator custom PropertyGrid samples.")]
[assembly: ComVisible(true)]
[assembly: Guid("9cf405ed-5c12-4ce8-bd2c-d5fb14ad1f18")]
[assembly: CLSCompliant(false)]