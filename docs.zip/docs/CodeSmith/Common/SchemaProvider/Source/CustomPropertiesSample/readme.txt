This project contains a sample of creating custom types and type editors for use as CodeSmith Generator properties.

The PurchaseOrderXml.cst contains an example of using a custom type that supports XML serialization in CodeSmith Generator as an alternative to using the XmlProperty directive.

Try double-clicking on the CustomPropertiesSample.cst template in windows explorer to see these custom types in use.
