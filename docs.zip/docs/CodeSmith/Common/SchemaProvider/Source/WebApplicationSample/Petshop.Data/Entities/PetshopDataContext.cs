
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Petshop.Data
{
    public partial class PetshopDataContext
    {
        #region Extensibility Method Definitions
        //TODO: Uncomment and implement partial method
        //partial void OnCreated()
        //{
        //    
        //}
        #endregion
        
    }
}