﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using SchemaExplorer;

namespace NHibernateHelper
{
    public class EntityMember : EntityBase
    {
        public EntityMember(ColumnSchema column)
            : base(column)
        {
            GenericName = GetGenericName(column);
            SystemType = GetSystemTypeName(column);
            IsRowVersion = (!column.IsPrimaryKeyMember && NHibernateHelper.VersionRegex.IsMatch(column.Name));
            Size = GetSize(column);
            NullSystemType = GetNullSystemTypeName(column);
            DbType =GetDbType(column.DataType);
        }

        private static string GetGenericName(ColumnSchema column)
        {
            if (ColumnHasAlias(column))
                return GetNameFromColumn(column);

            string genericName = GetNameFromColumn(column);
            return NHibernateHelper.ValidateName(column, genericName);
        }
        private static string GetSystemTypeName(ColumnSchema column)
        {
            //string result = (NHibernateHelper.SystemCSharpAliasMap.ContainsKey(column.SystemType.FullName))
            //    ? NHibernateHelper.SystemCSharpAliasMap[column.SystemType.FullName]
            //    : column.SystemType.FullName; --旧版  2012-5-12
           string result= (NHibernateHelper.SystemCSharpAliasMap.ContainsKey(column.DataType.ToString()))
              ? NHibernateHelper.SystemCSharpAliasMap[column.DataType.ToString()]
              : column.NativeType;
            return (column.AllowDBNull && column.SystemType.IsValueType)? String.Concat(result, "?"): result;
        }

        private static string GetNullSystemTypeName(ColumnSchema column)
        {
             //return (NHibernateHelper.SystemCSharpAliasMap.ContainsKey(column.SystemType.FullName))
             //   ? NHibernateHelper.SystemCSharpAliasMap[column.SystemType.FullName]
             //   : column.SystemType.FullName;  旧版
            string result = (NHibernateHelper.SystemCSharpAliasMap.ContainsKey(column.DataType.ToString()))
               ? NHibernateHelper.SystemCSharpAliasMap[column.DataType.ToString()]
               : column.NativeType;
            return (column.SystemType.IsValueType) ? String.Concat(result, "?") : result;

        }

        private  int GetSize(ColumnSchema column)
        {
            if (column.Size > 0) return column.Size;
            if (NHibernateHelper.NativeTypeCSharpSize == null || NHibernateHelper.NativeTypeCSharpSize.Count == 0) return 0;
            int result=0;
            if (NHibernateHelper.NativeTypeCSharpSize.ContainsKey(column.NativeType))
            {
                Int32.TryParse(NHibernateHelper.NativeTypeCSharpSize[column.NativeType], out result);
            }
            return result;
        }

        private DbType GetDbType(DbType dbType)
        {
            switch (dbType)
            {
                case DbType.SByte:
                    return DbType.Byte;
                case DbType.UInt16:
                    return DbType.Int16;
                case DbType.UInt32:
                    return DbType.Int32;
                case DbType.UInt64:
                    return DbType.Int64;
                case DbType.AnsiString:
                    return DbType.String;
                case DbType.AnsiStringFixedLength:
                    return DbType.String;
                default:
                    return dbType;
            }
          

        }

        public string SystemType { get; private set; }
        public bool IsRowVersion { get; private set; }

        public int Size { get; private set; }
        public DbType DbType { get; private set; }
        public string NullSystemType { get; private set; }


       

    }
}
